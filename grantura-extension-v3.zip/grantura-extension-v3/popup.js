// Grantura Popup v3
var provider = 'groq';

document.addEventListener('DOMContentLoaded', function() {
  // Tab buttons
  document.getElementById('t0').addEventListener('click', function(){ switchTab(0); });
  document.getElementById('t1').addEventListener('click', function(){ switchTab(1); });
  document.getElementById('t2').addEventListener('click', function(){ switchTab(2); });

  // Status tab
  document.getElementById('bscan').addEventListener('click', doScan);
  document.getElementById('bapp').addEventListener('click',  openApp);
  document.getElementById('bscan').disabled = true;

  // Docs tab
  document.getElementById('bapp2').addEventListener('click',    openApp);
  document.getElementById('bclrdocs').addEventListener('click', clearDocs);

  // Settings tab
  document.getElementById('sg0').addEventListener('click',      function(){ setProvider('groq'); });
  document.getElementById('sg1').addEventListener('click',      function(){ setProvider('gemini'); });
  document.getElementById('bsavekey').addEventListener('click', saveKey);
  document.getElementById('bclrkey').addEventListener('click',  clearKey);

  loadSettings();
  loadStatus();
  loadDocCount();
});

// ── TABS ──────────────────────────────────────
function switchTab(n) {
  for (var i=0; i<3; i++) {
    document.getElementById('t'+i).className = 'tab'+(i===n?' on':'');
    document.getElementById('p'+i).className = 'pane'+(i===n?' on':'');
  }
  if (n===1) loadDocs();
}

// ── SETTINGS ──────────────────────────────────
function loadSettings() {
  chrome.storage.local.get(['granturaApiKey','granturaProvider'], function(r) {
    provider = r.granturaProvider || 'groq';
    setProviderUI(provider);
    if (r.granturaApiKey) document.getElementById('kok').textContent = '✓ API key saved';
  });
}

function setProvider(p) {
  provider = p;
  chrome.storage.local.set({ granturaProvider: p });
  setProviderUI(p);
}

function setProviderUI(p) {
  document.getElementById('sg0').className = 'segbtn'+(p==='groq'?'   on':'');
  document.getElementById('sg1').className = 'segbtn'+(p==='gemini'?' on':'');
  document.getElementById('khint').textContent = p==='groq'
    ? 'Free key at console.groq.com'
    : 'Free key at aistudio.google.com/app/apikey';
}

function saveKey() {
  var k = document.getElementById('kfield').value.trim();
  if (!k) { document.getElementById('kok').textContent = 'Please paste a key first'; return; }
  chrome.storage.local.set({ granturaApiKey:k, granturaProvider:provider }, function() {
    document.getElementById('kfield').value = '';
    document.getElementById('kok').textContent = '✓ '+(provider==='groq'?'Groq':'Gemini')+' key saved!';
  });
}

function clearKey() {
  chrome.storage.local.remove(['granturaApiKey'], function() {
    document.getElementById('kok').textContent = 'Key cleared';
    document.getElementById('kfield').value = '';
  });
}

// ── STATUS ────────────────────────────────────
function loadDocCount() {
  chrome.storage.local.get(['granturaDocs'], function(r) {
    var docs = r.granturaDocs || {};
    document.getElementById('sd').textContent = Object.keys(docs).length;
    document.getElementById('sw').textContent = '—';
  });
}

function loadStatus() {
  chrome.tabs.query({ active:true, currentWindow:true }, function(tabs) {
    if (!tabs[0]) { setMsg('amber','Cannot access current tab.'); return; }

    var url = tabs[0].url || '';
    document.getElementById('curl').textContent = url.replace(/^https?:\/\//,'').substring(0,46);

    var done = false;
    var timer = setTimeout(function() {
      if (done) return; done=true;
      document.getElementById('sf').textContent = '0';
      setMsg('amber','No form detected here. Go to any page with a form.');
    }, 1800);

    chrome.tabs.sendMessage(tabs[0].id, {action:'ping'}, function(res) {
      if (done) return; done=true;
      clearTimeout(timer);
      if (chrome.runtime.lastError||!res) {
        document.getElementById('sf').textContent = '0';
        setMsg('amber','Go to any page with a form — Grantura activates automatically.');
        return;
      }
      document.getElementById('dot').className = 'dot';
      document.getElementById('stxt').textContent = 'Active';
      var fc = res.fields||0;
      document.getElementById('sf').textContent = fc;
      if (fc>0) {
        setMsg('blue', fc+' fields detected. Click Scan & Fill to prepare AI answers.');
        document.getElementById('bscan').disabled = false;
      } else {
        setMsg('amber','No form fields on this page.');
      }
    });
  });
}

function doScan() {
  var btn = document.getElementById('bscan');
  btn.disabled=true; btn.textContent='Scanning...';
  chrome.tabs.query({active:true,currentWindow:true}, function(tabs) {
    if (!tabs[0]) { btn.disabled=false; btn.textContent='🔍 Scan & Fill This Page'; return; }
    chrome.tabs.sendMessage(tabs[0].id, {action:'rescan'}, function(r) {
      btn.disabled=false; btn.innerHTML='🔍 Scan &amp; Fill This Page';
      setMsg(chrome.runtime.lastError?'red':'blue',
        chrome.runtime.lastError ? '⚠ Could not reach page. Refresh and try again.'
                                 : '⏳ Scanning and preparing AI answers... watch the sidebar on the page.');
    });
  });
}

// ── DOCUMENTS ─────────────────────────────────
function loadDocs() {
  chrome.storage.local.get(['granturaDocs'], function(r) {
    var docs = r.granturaDocs||{};
    var keys = Object.keys(docs);
    var el   = document.getElementById('doclist');
    if (!keys.length) {
      el.innerHTML = '<div class="nodocs">📭 No documents yet.<br>Open Grantura web app, upload your CVs,<br>then click "Send to Extension".</div>';
      return;
    }
    el.innerHTML = '';
    keys.forEach(function(k) {
      var d    = docs[k];
      var item = document.createElement('div');
      item.className = 'doc-item';
      item.innerHTML = '<div><div class="doc-name">📄 '+(d.name||k)+'</div>' +
        '<div class="doc-meta">'+(d.pages||0)+' pages · '+Math.round((d.text||'').length/1000)+'k chars</div></div>';
      var del = document.createElement('button');
      del.className='doc-del'; del.textContent='✕';
      del.addEventListener('click', function(){ deleteDoc(k); });
      item.appendChild(del);
      el.appendChild(item);
    });
  });
}

function deleteDoc(key) {
  chrome.storage.local.get(['granturaDocs'], function(r) {
    var docs = r.granturaDocs||{};
    delete docs[key];
    chrome.storage.local.set({granturaDocs:docs}, loadDocs);
  });
}

function clearDocs() {
  if (!confirm('Remove all loaded documents?')) return;
  chrome.storage.local.remove(['granturaDocs'], loadDocs);
}

// ── HELPERS ───────────────────────────────────
function openApp() {
  chrome.tabs.create({ url:'https://tosharetoday007.github.io/grantura/' });
}

function setMsg(cls, text) {
  document.getElementById('smsg').innerHTML =
    '<div class="msg '+cls+'" style="margin-bottom:9px;">'+text+'</div>';
}
