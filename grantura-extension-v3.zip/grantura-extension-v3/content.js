// ═══════════════════════════════════════════════════════════
// GRANTURA CONTENT SCRIPT v3
// Runs on every page. Detects real forms. Shows sidebar.
// Sends fields to background for AI answers. Fills form.
// Works on: standard HTML, Google Forms, ministry portals,
//           React/Vue/Angular apps, any website.
// ═══════════════════════════════════════════════════════════
(function() {
  'use strict';
  if (window.__GRANTURA_V3__) return;
  window.__GRANTURA_V3__ = true;

  var SB_ID = '__g3_sidebar__';
  var pageFields  = [];
  var pageAnswers = [];
  var fillCount   = 0;
  var warnings    = [];

  // ── 1. SCAN FIELDS ──────────────────────────────────────
  function scanFields() {
    var results = [];
    var seen = new Set();

    // Standard HTML fields
    var els = document.querySelectorAll(
      'input:not([type=hidden]):not([type=submit]):not([type=button]):not([type=reset]):not([type=image]),' +
      'textarea, select'
    );
    els.forEach(function(el) {
      if (!visible(el)) return;
      var label    = getLabel(el);
      var selector = getSelector(el);
      var key = label + '||' + selector;
      if (seen.has(key)) return;
      seen.add(key);
      results.push({
        label:       label,
        selector:    selector,
        type:        getType(el),
        limitHint:   getLimit(el),
        placeholder: el.placeholder || '',
        required:    el.required || false,
        options:     el.tagName === 'SELECT'
                       ? Array.from(el.options).map(function(o){ return {value:o.value, text:o.text}; })
                       : []
      });
    });

    // Google Forms div-based fields
    var gfContainers = document.querySelectorAll(
      '.freebirdFormviewerComponentsQuestionBaseRoot,' +
      '.freebirdFormviewerViewItemsItemItem'
    );
    gfContainers.forEach(function(c) {
      var titleEl = c.querySelector('.M7eMe, .freebirdFormviewerComponentsQuestionBaseTitle, [role="heading"]');
      if (!titleEl) return;
      var label = trim(titleEl.innerText);
      if (!label || seen.has('gf:'+label)) return;
      seen.add('gf:'+label);

      var type = 'text';
      var options = [];
      if (c.querySelector('[role="radio"]'))    type = 'radio';
      if (c.querySelector('[role="checkbox"]')) type = 'checkbox';
      if (c.querySelector('[role="listbox"]'))  type = 'select';
      if (c.querySelector('textarea'))          type = 'textarea';

      c.querySelectorAll('[data-value], .nWQGrd, .docssharedWizToggleLabeledLabelWrapper').forEach(function(o) {
        var t = trim(o.getAttribute('data-value') || o.innerText || '');
        if (t && !options.find(function(x){ return x.text===t; })) options.push({value:t, text:t});
      });

      results.push({ label:label, selector:'', type:type, limitHint:'', placeholder:'', required:false, options:options });
    });

    return results;
  }

  function visible(el) {
    var s = window.getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && el.offsetHeight > 0;
  }

  function getLabel(el) {
    if (el.id) { try { var l = document.querySelector('label[for="'+CSS.escape(el.id)+'"]'); if (l && l.innerText.trim()) return trim(l.innerText); } catch(e){} }
    if (el.getAttribute('aria-label')) return el.getAttribute('aria-label').trim();
    var lblId = el.getAttribute('aria-labelledby');
    if (lblId) { var r = document.getElementById(lblId); if (r) return trim(r.innerText); }
    var wrap = el.closest('label'); if (wrap) return trim(wrap.innerText);
    var p = el.parentElement;
    for (var i=0; i<5; i++) {
      if (!p) break;
      var lbl = p.querySelector('label,legend,[class*="label"],[class*="title"],[class*="question"]');
      if (lbl && !lbl.contains(el) && lbl.innerText.trim().length > 1) return trim(lbl.innerText);
      var prev = el.previousElementSibling;
      if (prev && !prev.querySelector('input,textarea,select') && prev.innerText && prev.innerText.trim().length > 1) return trim(prev.innerText);
      p = p.parentElement;
    }
    if (el.placeholder && el.placeholder.length > 1) return el.placeholder;
    if (el.name) return el.name.replace(/[_\-\[\]]/g,' ').trim();
    return 'Field';
  }

  function getSelector(el) {
    if (el.id) { try { return '#'+CSS.escape(el.id); } catch(e){} }
    if (el.name) return el.tagName.toLowerCase()+'[name="'+el.name+'"]';
    var all = document.querySelectorAll(el.tagName);
    for (var i=0; i<all.length; i++) { if (all[i]===el) return el.tagName.toLowerCase()+':nth-of-type('+(i+1)+')'; }
    return el.tagName.toLowerCase();
  }

  function getType(el) {
    if (el.tagName==='SELECT')   return 'select';
    if (el.tagName==='TEXTAREA') return 'textarea';
    return (el.type||'text').toLowerCase();
  }

  function getLimit(el) {
    if (el.maxLength>0 && el.maxLength<99999) return el.maxLength+' chars max';
    var p = el.parentElement ? (el.parentElement.innerText||'') : '';
    var m = p.match(/(\d[\d,]*)\s*(words?|chars?|characters?)/i);
    return m ? m[0] : '';
  }

  function trim(t) { return (t||'').replace(/\s+/g,' ').replace(/\*\s*$/,'').trim(); }

  // ── 2. IS THIS A REAL FORM? ──────────────────────────────
  function isRealForm(fields) {
    if (fields.length < 2) return false;

    var passwords = fields.filter(function(f){ return f.type==='password'; });
    // Skip pure login pages (email/user + password only)
    if (passwords.length >= 1 && fields.length <= 3) return false;

    // Skip single search box
    if (fields.length === 1) return false;

    // If 4+ fields — always a real form
    if (fields.length >= 4) return true;

    // For 2-3 fields check for application keywords in labels
    var keywords = ['name','email','phone','address','research','project','title',
      'institution','university','date','birth','nationality','description',
      'motivation','experience','budget','application','apply','qualification',
      'education','position','expertise','domain','language','nombre','correo',
      'apellido','investigación','solicitud','passport','linkedin','portfolio'];
    var labelText = fields.map(function(f){ return (f.label||'').toLowerCase(); }).join(' ');
    return keywords.some(function(k){ return labelText.includes(k); });
  }

  // ── 3. FILL FIELDS ───────────────────────────────────────
  function fillAll() {
    fillCount = 0;
    warnings  = [];

    pageAnswers.forEach(function(ans) {
      if (!ans.value || !ans.value.trim()) {
        if (ans.label) warnings.push({ label: ans.label, note: ans.note || 'Not found in documents — fill manually', type: 'manual' });
        return;
      }

      var filled = false;

      // Layer 1: standard selector
      if (ans.selector) {
        try {
          var el = document.querySelector(ans.selector);
          if (el && visible(el)) filled = fillElement(el, ans);
        } catch(e) {}
      }

      // Layer 2: Google Forms
      if (!filled) filled = fillGoogleForms(ans);

      // Layer 3: label text search
      if (!filled) filled = fillByLabel(ans);

      if (!filled) warnings.push({ label: ans.label, note: 'Could not locate field on this page', type: 'warn' });
    });

    // Save results to background
    chrome.runtime.sendMessage({
      action: 'saveFormResult',
      result: {
        url:     window.location.href,
        title:   document.title,
        ts:      Date.now(),
        filled:  fillCount,
        total:   pageAnswers.length,
        answers: pageAnswers,
        warnings: warnings
      }
    });

    showSidebar('done');
  }

  function fillElement(el, ans) {
    try {
      if (el.tagName==='SELECT') {
        var opts = Array.from(el.options);
        var best = opts.find(function(o){
          return o.text.toLowerCase().includes(ans.value.toLowerCase()) ||
                 ans.value.toLowerCase().includes(o.text.toLowerCase());
        });
        if (best) { el.value=best.value; fire(el); mark(el,'ok'); fillCount++; return true; }
        warnings.push({ label:ans.label, note:'No matching option. Options: '+opts.slice(1).map(function(o){return o.text;}).join(', '), type:'warn' });
        return false;
      }
      if (el.type==='checkbox'||el.type==='radio') {
        el.checked = /^(yes|true|1|on|✓)$/i.test(ans.value.trim());
        fire(el); mark(el,'ok'); fillCount++; return true;
      }
      var proto  = el.tagName==='TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
      var setter = Object.getOwnPropertyDescriptor(proto,'value');
      if (setter&&setter.set) setter.set.call(el, ans.value); else el.value = ans.value;
      fire(el);
      var limitWarn = checkLimit(ans.value, ans.limitHint);
      if (limitWarn) { mark(el,'warn'); warnings.push({label:ans.label,note:limitWarn,type:'warn'}); }
      else { mark(el,'ok'); fillCount++; }
      return true;
    } catch(e) { return false; }
  }

  function fillGoogleForms(ans) {
    var valLow = ans.value.toLowerCase().trim();
    var labLow = (ans.label||'').toLowerCase().trim();

    var containers = document.querySelectorAll(
      '.freebirdFormviewerComponentsQuestionBaseRoot,' +
      '.freebirdFormviewerViewItemsItemItem'
    );

    for (var i=0; i<containers.length; i++) {
      var c = containers[i];
      var titleEl = c.querySelector('.M7eMe,.freebirdFormviewerComponentsQuestionBaseTitle,[role="heading"]');
      if (!titleEl) continue;
      var cTitle = trim(titleEl.innerText).toLowerCase();

      // Match question title to answer label
      var match = cTitle.includes(labLow.substring(0,12)) || labLow.includes(cTitle.substring(0,12));
      if (!match) continue;

      // Text input
      var inp = c.querySelector('input[type="text"],input[type="email"],input[type="number"],textarea');
      if (inp) {
        var proto  = inp.tagName==='TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
        var setter = Object.getOwnPropertyDescriptor(proto,'value');
        if (setter&&setter.set) setter.set.call(inp, ans.value); else inp.value = ans.value;
        fire(inp); mark(inp,'ok'); fillCount++; return true;
      }

      // Radio
      var radios = c.querySelectorAll('[role="radio"]');
      if (radios.length) {
        var best=null, bestScore=0;
        radios.forEach(function(r) {
          var rt = (r.getAttribute('data-value')||r.innerText||'').toLowerCase().trim();
          var score = rt===valLow?100 : valLow.includes(rt)?80 : rt.includes(valLow)?70 : 0;
          if (score>bestScore) { bestScore=score; best=r; }
        });
        if (best&&bestScore>0) { best.click(); mark(best,'ok'); fillCount++; return true; }
      }

      // Checkbox (multi-select) — split by comma
      var cbs = c.querySelectorAll('[role="checkbox"]');
      if (cbs.length) {
        var parts = ans.value.split(/[,;]/).map(function(v){ return v.trim().toLowerCase(); });
        var any = false;
        cbs.forEach(function(cb) {
          var ct = (cb.getAttribute('data-value')||cb.innerText||'').toLowerCase().trim();
          if (parts.some(function(p){ return ct.includes(p)||p.includes(ct); })) {
            cb.click(); mark(cb,'ok'); fillCount++; any=true;
          }
        });
        if (any) return true;
      }

      // Listbox dropdown
      var lb = c.querySelector('[role="listbox"]');
      if (lb) {
        lb.click();
        setTimeout(function() {
          var opts = document.querySelectorAll('[role="option"]');
          opts.forEach(function(o) {
            if ((o.innerText||'').toLowerCase().includes(valLow)) { o.click(); mark(lb,'ok'); fillCount++; }
          });
        }, 350);
        return true;
      }
    }
    return false;
  }

  function fillByLabel(ans) {
    var labLow = (ans.label||'').toLowerCase().substring(0,20);
    if (!labLow) return false;
    var inputs = document.querySelectorAll('input[type="text"],input[type="email"],input[type="number"],textarea');
    for (var i=0; i<inputs.length; i++) {
      var inp = inputs[i];
      var nearby = inp.closest('div,li,section,fieldset');
      if (!nearby) continue;
      if (!(nearby.innerText||'').toLowerCase().includes(labLow)) continue;
      var proto  = inp.tagName==='TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
      var setter = Object.getOwnPropertyDescriptor(proto,'value');
      if (setter&&setter.set) setter.set.call(inp, ans.value); else inp.value = ans.value;
      fire(inp); mark(inp,'ok'); fillCount++; return true;
    }
    return false;
  }

  function fire(el) {
    ['input','change','blur','keyup'].forEach(function(e){ el.dispatchEvent(new Event(e,{bubbles:true})); });
  }

  function mark(el, type) {
    var bg = {ok:'rgba(30,158,110,0.12)', warn:'rgba(255,165,0,0.15)', manual:'rgba(58,111,181,0.10)'};
    var bd = {ok:'2px solid rgba(30,158,110,0.5)', warn:'2px solid rgba(255,165,0,0.7)', manual:'2px solid rgba(58,111,181,0.4)'};
    el.style.transition='all 0.3s'; el.style.background=bg[type]||bg.ok; el.style.outline=bd[type]||bd.ok;
  }

  function checkLimit(value, hint) {
    if (!hint) return '';
    var n = hint.match(/(\d[\d,]*)/); if (!n) return '';
    var limit = parseInt(n[1].replace(/,/g,''));
    var isWords = /word/i.test(hint);
    var count = isWords ? value.trim().split(/\s+/).length : value.length;
    return count>limit ? 'Answer has '+count+(isWords?' words':' chars')+', limit is '+limit+'. Please shorten.' : '';
  }

  // ── 4. SIDEBAR ───────────────────────────────────────────
  function injectStyles() {
    if (document.getElementById('__g3_css__')) return;
    var s = document.createElement('style');
    s.id = '__g3_css__';
    s.textContent = `
      #__g3_sidebar__ {
        all:initial !important;
        position:fixed !important; top:80px !important; right:0 !important;
        width:285px !important; z-index:2147483647 !important;
        font-family:-apple-system,'Segoe UI',sans-serif !important;
        font-size:13px !important; line-height:1.4 !important;
        background:#fff !important; color:#1a1c26 !important;
        border:1px solid #dde1ec !important; border-right:none !important;
        border-radius:12px 0 0 12px !important;
        box-shadow:-4px 8px 32px rgba(0,0,0,0.13) !important;
        transition:transform 0.3s ease !important; overflow:hidden !important;
      }
      #__g3_sidebar__.g3-hide { transform:translateX(260px) !important; }
      .g3h { background:linear-gradient(135deg,#a07830,#3a6fb5); padding:10px 13px; color:white; display:flex; align-items:center; justify-content:space-between; }
      .g3logo { font-weight:800; font-size:13px; letter-spacing:-0.2px; }
      .g3tog { background:none; border:none; color:white; cursor:pointer; font-size:13px; padding:3px 7px; border-radius:4px; }
      .g3tog:hover { background:rgba(255,255,255,0.2); }
      .g3site { font-size:10px; color:#6b6f82; padding:5px 13px; border-bottom:1px solid #f0f2f8; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; background:#fafbfd; }
      .g3body { padding:12px 13px; max-height:62vh; overflow-y:auto; }
      .g3ttl { font-size:10px; font-weight:800; letter-spacing:1.2px; text-transform:uppercase; margin-bottom:8px; }
      .g3spin { width:22px; height:22px; border:2px solid #eee; border-top-color:#a07830; border-radius:50%; animation:g3spin 0.7s linear infinite; margin:12px auto; }
      .g3spin.blue { border-top-color:#3a6fb5; }
      @keyframes g3spin { to{transform:rotate(360deg)} }
      .g3stats { display:grid; grid-template-columns:repeat(3,1fr); gap:5px; margin-bottom:10px; }
      .g3stat { background:#f8f9fc; border:1px solid #eee; border-radius:7px; padding:7px 4px; text-align:center; }
      .g3sn { font-size:19px; font-weight:800; }
      .g3sl { font-size:9px; color:#6b6f82; text-transform:uppercase; letter-spacing:0.4px; }
      .g3row { display:flex; align-items:flex-start; gap:7px; padding:6px 8px; border-radius:7px; margin-bottom:4px; font-size:11px; }
      .g3ok   { background:rgba(30,158,110,0.07);  border:1px solid rgba(30,158,110,0.2); }
      .g3warn { background:rgba(255,165,0,0.07);   border:1px solid rgba(255,165,0,0.3); }
      .g3man  { background:rgba(58,111,181,0.07);  border:1px solid rgba(58,111,181,0.2); }
      .g3err  { background:rgba(192,57,74,0.07);   border:1px solid rgba(192,57,74,0.2); }
      .g3lbl { flex:1; font-weight:500; word-break:break-word; }
      .g3note { font-size:10px; color:#6b6f82; margin-top:2px; }
      .g3btn { width:100%; padding:9px; border-radius:7px; border:none; font-size:12px; font-weight:700; cursor:pointer; font-family:inherit; transition:all 0.2s; margin-top:7px; display:block; }
      .g3gold { background:#a07830; color:white; }
      .g3gold:hover { background:#c49040; }
      .g3ghost { background:#f1f3f8; color:#1a1c26; border:1px solid #dde1ec; }
      .g3ghost:hover { border-color:#a07830; color:#a07830; }
      .g3foot { font-size:10px; color:#9b9fb2; text-align:center; padding:7px; border-top:1px solid #f0f2f8; background:#fafbfd; }
      .g3msg { padding:9px 11px; border-radius:8px; font-size:12px; line-height:1.6; margin-bottom:8px; }
      .g3blue  { background:rgba(58,111,181,0.07); border:1px solid rgba(58,111,181,0.25); color:#2a5a9a; }
      .g3amber { background:rgba(160,120,48,0.07); border:1px solid rgba(160,120,48,0.25); color:#7a5010; }
      .g3red   { background:rgba(192,57,74,0.07);  border:1px solid rgba(192,57,74,0.25);  color:#a02030; }
    `;
    document.head.appendChild(s);
  }

  function showSidebar(phase, extra) {
    injectStyles();
    var sb = document.getElementById(SB_ID);
    if (!sb) { sb = document.createElement('div'); sb.id = SB_ID; document.body.appendChild(sb); }

    var host = window.location.hostname;
    var aiCount  = pageAnswers.filter(function(a){ return a.value&&a.value.trim(); }).length;
    var manCount = pageAnswers.filter(function(a){ return !a.value||!a.value.trim(); }).length;
    var body = '';

    if (phase==='thinking') {
      body = '<div class="g3ttl" style="color:#3a6fb5;">⏳ Reading form...</div>' +
             '<div class="g3spin blue"></div>' +
             '<div style="font-size:11px;color:#6b6f82;text-align:center;">Scanning '+pageFields.length+' fields<br>and preparing AI answers</div>';
    }

    else if (phase==='nodocs') {
      body = '<div class="g3ttl" style="color:#a02030;">⚠ No documents loaded</div>' +
             '<div class="g3msg g3amber">Open Grantura, upload your CV, click <strong>Send to Extension</strong> — then come back here.</div>' +
             '<button class="g3btn g3gold" id="g3_open">Open Grantura →</button>';
    }

    else if (phase==='error') {
      body = '<div class="g3ttl" style="color:#a02030;">⚠ Error</div>' +
             '<div class="g3msg g3red">'+(extra||'Unknown error')+'</div>' +
             '<button class="g3btn g3ghost" id="g3_rescan">🔄 Try Again</button>';
    }

    else if (phase==='ready') {
      body = '<div class="g3ttl" style="color:#1e9e6e;">✓ Answers ready — '+pageFields.length+' fields</div>';
      body += '<div class="g3stats">' +
        '<div class="g3stat"><div class="g3sn" style="color:#1e9e6e;">'+aiCount+'</div><div class="g3sl">AI ready</div></div>' +
        '<div class="g3stat"><div class="g3sn" style="color:#a07830;">'+manCount+'</div><div class="g3sl">Manual</div></div>' +
        '<div class="g3stat"><div class="g3sn">'+pageFields.length+'</div><div class="g3sl">Total</div></div>' +
        '</div>';
      pageAnswers.slice(0,5).forEach(function(a) {
        var cls = a.value ? 'g3ok' : 'g3man';
        body += '<div class="g3row '+cls+'">'+(a.value?'✓':'⚠')+'<div class="g3lbl">'+
          (a.label||'').substring(0,32)+(a.label&&a.label.length>32?'…':'')+'</div></div>';
      });
      if (pageAnswers.length>5) body += '<div style="font-size:10px;color:#9b9fb2;text-align:center;margin-top:3px;">+'+(pageAnswers.length-5)+' more</div>';
      body += '<button class="g3btn g3gold" id="g3_fill">⚡ Fill This Page Now</button>';
      body += '<button class="g3btn g3ghost" id="g3_rescan">🔄 Re-scan Page</button>';
    }

    else if (phase==='done') {
      body = '<div class="g3ttl" style="color:#1e9e6e;">✅ Filled '+fillCount+' fields</div>';
      if (warnings.length===0) {
        body += '<div class="g3row g3ok">✓<div class="g3lbl">All fields filled! Click Next to continue.</div></div>';
      } else {
        body += '<div style="font-size:10px;font-weight:700;color:#a02030;margin-bottom:5px;">⚠ '+warnings.length+' field(s) need attention:</div>';
        warnings.forEach(function(w) {
          var cls = w.type==='warn' ? 'g3warn' : 'g3man';
          body += '<div class="g3row '+cls+'">⚠<div><div class="g3lbl">'+
            (w.label||'').substring(0,30)+'</div><div class="g3note">'+(w.note||'')+'</div></div></div>';
        });
      }
      body += '<button class="g3btn g3ghost" id="g3_rescan" style="margin-top:8px;">🔄 Re-scan This Page</button>';
    }

    sb.innerHTML =
      '<div class="g3h"><span class="g3logo">🎓 Grantura</span>' +
      '<button class="g3tog" id="g3_tog" title="Collapse/Expand">◀</button></div>' +
      '<div class="g3site">'+host+' — '+pageFields.length+' fields</div>' +
      '<div class="g3body">'+body+'</div>' +
      '<div class="g3foot">🔒 Your documents never leave your device</div>';

    // Attach events via addEventListener (CSP requires this)
    addEv('g3_tog',    function(){ sb.classList.toggle('g3-hide'); });
    addEv('g3_fill',   doFill);
    addEv('g3_rescan', doRescan);
    addEv('g3_open',   function(){ window.open('https://tosharetoday007.github.io/grantura/','_blank'); });
  }

  function addEv(id, fn) {
    var el = document.getElementById(id);
    if (el) el.addEventListener('click', fn);
  }

  // ── 5. MAIN FLOW ─────────────────────────────────────────
  function init() {
    var fields = scanFields();
    if (!isRealForm(fields)) return; // not a real application form — do nothing

    pageFields = fields;
    showSidebar('thinking');

    chrome.storage.local.get(['granturaDocs','granturaApiKey','granturaProvider'], function(r) {
      var docs     = r.granturaDocs     || {};
      var apiKey   = r.granturaApiKey   || '';
      var provider = r.granturaProvider || 'groq';

      if (!Object.keys(docs).length) { showSidebar('nodocs'); return; }

      chrome.runtime.sendMessage({
        action:   'fillPage',
        fields:   fields,
        docs:     docs,
        apiKey:   apiKey,
        provider: provider,
        url:      window.location.href,
        title:    document.title
      }, function(response) {
        if (chrome.runtime.lastError) {
          showSidebar('error', 'Background error: '+chrome.runtime.lastError.message);
          return;
        }
        if (!response)         { showSidebar('error', 'No response. Try reloading the page.'); return; }
        if (response.error)    { showSidebar('error', response.error); return; }
        if (!response.answers || !response.answers.length) {
          showSidebar('error', 'AI returned no answers. Check your API key in extension Settings.'); return;
        }
        pageAnswers = response.answers;
        showSidebar('ready');
      });
    });
  }

  function doFill() {
    fillCount = 0; warnings = [];
    // collect manual corrections too
    pageAnswers.filter(function(a){ return !a.value||!a.value.trim(); }).forEach(function(a){
      warnings.push({ label:a.label, note:a.note||'Not in documents — fill manually', type:'manual' });
    });
    fillAll();
  }

  function doRescan() {
    pageFields=[]; pageAnswers=[]; fillCount=0; warnings=[];
    var sb = document.getElementById(SB_ID);
    if (sb) sb.remove();
    window.__GRANTURA_V3__ = false;
    setTimeout(function(){ window.__GRANTURA_V3__=true; init(); }, 400);
  }

  // ── 6. MESSAGES FROM POPUP ───────────────────────────────
  chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
    if (msg.action==='ping')   { sendResponse({alive:true, fields:pageFields.length, url:window.location.href}); }
    if (msg.action==='rescan') { doRescan(); sendResponse({ok:true}); }
    return true;
  });

  // ── 7. SPA NAVIGATION DETECTION ─────────────────────────
  var lastHref = location.href;
  new MutationObserver(function() {
    if (location.href !== lastHref) {
      lastHref = location.href;
      pageFields=[]; pageAnswers=[];
      var sb = document.getElementById(SB_ID);
      if (sb) sb.remove();
      window.__GRANTURA_V3__ = false;
      setTimeout(function(){ window.__GRANTURA_V3__=true; init(); }, 1500);
    }
  }).observe(document.body, {childList:true, subtree:true});

  // ── START ─────────────────────────────────────────────
  setTimeout(init, 1500);

})();
