// Grantura Bridge v3 — runs on Grantura web app only
// Bridges web app ↔ extension via postMessage
(function() {
  'use strict';

  window.addEventListener('message', function(e) {
    if (e.source !== window || !e.data || e.data.source !== 'grantura-webapp') return;

    if (e.data.type === 'PING') {
      window.postMessage({ source:'grantura-extension', type:'PONG', version:'3.0.0' }, '*');
    }

    if (e.data.type === 'SEND_DOCS') {
      chrome.storage.local.set({
        granturaDocs:     e.data.docs,
        granturaApiKey:   e.data.apiKey   || '',
        granturaProvider: e.data.provider || 'groq'
      }, function() {
        window.postMessage({
          source: 'grantura-extension',
          type:   'SEND_DOCS_RESULT',
          ok:     !chrome.runtime.lastError,
          count:  Object.keys(e.data.docs).length,
          error:  chrome.runtime.lastError ? chrome.runtime.lastError.message : null
        }, '*');
      });
    }

    if (e.data.type === 'GET_FORM_RESULT') {
      chrome.storage.local.get(['granturaLastResult'], function(r) {
        window.postMessage({ source:'grantura-extension', type:'FORM_RESULT', data: r.granturaLastResult||null }, '*');
      });
    }
  });

  // Announce presence
  window.postMessage({ source:'grantura-extension', type:'READY', version:'3.0.0' }, '*');
})();
