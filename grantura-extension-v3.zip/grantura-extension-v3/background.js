// ═══════════════════════════════════════════════
// GRANTURA BACKGROUND v3
// Receives scanned fields → calls AI → returns answers
// ═══════════════════════════════════════════════

// Clear stale cache on install/update
chrome.runtime.onInstalled.addListener(function() {
  chrome.storage.local.remove(['granturaCache']);
});

chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {

  if (msg.action === 'fillPage') {
    handleFillPage(msg).then(sendResponse).catch(function(e) {
      sendResponse({ error: e.message });
    });
    return true; // async
  }

  if (msg.action === 'saveSettings') {
    chrome.storage.local.set({
      granturaDocs:     msg.docs     || {},
      granturaApiKey:   msg.apiKey   || '',
      granturaProvider: msg.provider || 'groq'
    }, function() { sendResponse({ ok: true }); });
    return true;
  }

  if (msg.action === 'getSettings') {
    chrome.storage.local.get(['granturaDocs','granturaApiKey','granturaProvider'], function(r) {
      sendResponse({ docs: r.granturaDocs || {}, apiKey: r.granturaApiKey || '', provider: r.granturaProvider || 'groq' });
    });
    return true;
  }

  if (msg.action === 'saveFormResult') {
    chrome.storage.local.set({ granturaLastResult: msg.result });
    sendResponse({ ok: true });
    return true;
  }

  if (msg.action === 'getFormResult') {
    chrome.storage.local.get(['granturaLastResult'], function(r) {
      sendResponse({ result: r.granturaLastResult || null });
    });
    return true;
  }

});

// ── MAIN: FILL PAGE ────────────────────────────
async function handleFillPage(msg) {
  var fields   = msg.fields   || [];
  var docs     = msg.docs     || {};
  var apiKey   = msg.apiKey   || '';
  var provider = msg.provider || 'groq';

  if (fields.length === 0) return { answers: [] };

  // Fallback: read from storage if not passed
  if (!apiKey) {
    var stored = await storageGet(['granturaApiKey','granturaProvider','granturaDocs']);
    apiKey   = stored.granturaApiKey   || '';
    provider = stored.granturaProvider || 'groq';
    if (!Object.keys(docs).length) docs = stored.granturaDocs || {};
  }

  if (!apiKey) return { error: 'No API key. Open extension → Settings → save your Groq or Gemini key.' };
  if (!Object.keys(docs).length) return { error: 'No documents. Open Grantura web app, upload your CV, click Send to Extension.' };

  var prompt  = buildPrompt(fields, docs, msg.url, msg.title);
  var rawText = await callAI(apiKey, provider, prompt);
  var answers = parseJSON(rawText, fields);
  return { answers: answers };
}

// ── BUILD PROMPT ───────────────────────────────
function buildPrompt(fields, docs, url, title) {
  var docText = Object.keys(docs).map(function(k) {
    return '=== ' + (docs[k].name || k).toUpperCase() + ' ===\n' + (docs[k].text || '').substring(0, 3500);
  }).join('\n\n');

  var fieldList = fields.map(function(f, i) {
    var d = (i+1) + '. LABEL: "' + f.label + '" | TYPE: ' + f.type;
    if (f.limitHint)  d += ' | LIMIT: ' + f.limitHint;
    if (f.required)   d += ' | REQUIRED';
    if (f.options && f.options.length) d += '\n   OPTIONS: ' + f.options.map(function(o){ return '"'+o.text+'"'; }).join(', ');
    d += '\n   SELECTOR: ' + (f.selector || 'use-label');
    return d;
  }).join('\n\n');

  return 'You are filling a form on: "' + title + '" (' + url + ')\n\n' +
'APPLICANT DOCUMENTS:\n' + docText + '\n\n' +
'FORM FIELDS:\n' + fieldList + '\n\n' +
'RULES:\n' +
'- Extract name, email, phone, address directly from documents\n' +
'- For RADIO/CHECKBOX: value must be EXACTLY one of the listed options\n' +
'- For SELECT/DROPDOWN: value must match an option text exactly\n' +
'- For LANGUAGE checkboxes: select all languages found in documents\n' +
'- If not found in documents: return empty string, explain in note\n' +
'- Never invent information not in documents\n' +
'- Return ONLY valid JSON array, no markdown fences\n\n' +
'JSON format:\n' +
'[{"selector":"...","label":"...","value":"answer or empty","note":"explanation"}]';
}

// ── CALL AI ────────────────────────────────────
async function callAI(apiKey, provider, prompt) {
  var url, body, headers;

  if (provider === 'gemini') {
    url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=' + apiKey;
    headers = { 'Content-Type': 'application/json' };
    body = JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0.1, maxOutputTokens: 4096 }
    });
  } else {
    url = 'https://api.groq.com/openai/v1/chat/completions';
    headers = { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + apiKey };
    body = JSON.stringify({
      model: 'llama-3.3-70b-versatile',
      messages: [
        { role: 'system', content: 'You are a precise form-filling assistant. Return ONLY valid JSON arrays. No markdown. No explanation outside JSON.' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.1,
      max_tokens: 4096
    });
  }

  var resp = await fetch(url, { method: 'POST', headers: headers, body: body });

  if (!resp.ok) {
    var err = await resp.json().catch(function(){ return {}; });
    var msg = (err.error && err.error.message) || ('API error ' + resp.status);
    throw new Error(msg);
  }

  var data = await resp.json();
  if (provider === 'gemini') {
    return data.candidates[0].content.parts[0].text;
  } else {
    return data.choices[0].message.content;
  }
}

// ── PARSE JSON RESPONSE ────────────────────────
function parseJSON(raw, fields) {
  try {
    var cleaned = raw.replace(/```json\s*/gi,'').replace(/```/g,'').trim();
    var start = cleaned.indexOf('[');
    var end   = cleaned.lastIndexOf(']');
    if (start === -1 || end === -1) throw new Error('No array found');
    var arr = JSON.parse(cleaned.substring(start, end+1));
    if (!Array.isArray(arr)) throw new Error('Not an array');
    return arr;
  } catch(e) {
    // Return empty answers for all fields on parse failure
    return fields.map(function(f) {
      return { selector: f.selector, label: f.label, value: '', note: 'AI parse error — try re-scanning' };
    });
  }
}

// ── HELPER ─────────────────────────────────────
function storageGet(keys) {
  return new Promise(function(resolve) { chrome.storage.local.get(keys, resolve); });
}
